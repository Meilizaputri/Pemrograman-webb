 <div class="col-md-6">
			<article>
			
<div class="active list-group-item">
  <p><em> <strong>WEBSITE SMA NEGERI 1 JARAI</strong></em></p> width
  <p><img src="20200106_134630.jpg" width="244" height="224" /> <img src="20200106_143639.jpg" width="240" height="243" /> <img src="IMG_20200106_142319.jpg" width="256" height="248" /> <img src="IMG_20200106_142124.jpg" width="229" height="244" /><img src="IMG_20200106_142648.jpg" width="260" height="312" /> <img src="20200106_143741.jpg" width="227" height="310" /></p>
</div>
				</article>
		</div>
        
<div class="col-md-3">
<div class="list-group">
<a href="#" class="list-group-item active"><em class="glyphicon glyphicon-file"></em>Berita WEBSITE SMA NEGERI 1 JARAI</a>
<div class="alert alert-success"></div>
</div>
<div class="alert alert-success"><head>
<link href="css/style.css" rel="stylesheet">
<body>

<div id="clockDisplay" class="clockStyle">
<script type="text/javascript" language="javascript">
function renderTime(){
 var currentTime = new Date();
 var h = currentTime.getHours();
 var m = currentTime.getMinutes();
 var s = currentTime.getSeconds();
 if (h == 0){
  h = 24;
   }
   if (h < 10){
    h = "0" + h;
    }
    if (m < 10){
    m = "0" + m;
    }
    if (s < 10){
    s = "0" + s;
    }
 var myClock = document.getElementById('clockDisplay');
 myClock.textContent = h + ":" + m + ":" + s + "";    
 setTimeout ('renderTime()',1000);
 }
 renderTime();
</script>

</div>

</body>
</html></div>
</div>
</div>	<!--baris tutup-->


	<div class="row">
		<div class="col-md-12">
			<footer class="well">
			  <p>Copyright &copy; 2019</p>
			</footer>
		</div>
	</div>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>"
							$(function() {
									//bootstrap WYSIHTML5 - text editor
									$(".textarea").wysihtml5();
  								$('[data-toggle="tooltip"]').tooltip();
							});
	</script>

</body>
</html>