<div class="container">
	<div class="alert alert-info">
		<h4>Data Mahasiswa</h4>
	</div>
<table class="table">
	<tr>
		<td>No</td>
		<td>NPM</td>
		<td>Nama</td>
		<td>Jenis Kelamin</td>
		<td>Program Studi</td>
	</tr>
	<?php 
		$no=1;
		foreach ($meili as $mli):
	?>
	<tr>
		<td><?php echo $no++ ?></td>
		<td><?php echo $mli->npm ?></td>
		<td><?php echo $mli->nama ?></td>
		<td><?php echo $mli->jk ?></td>
		<td><?php echo $mli->prodi ?></td>
	</tr>
<?php endforeach; ?>
</table>
</div>
